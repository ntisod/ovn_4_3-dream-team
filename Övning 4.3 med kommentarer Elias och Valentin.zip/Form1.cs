﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Övning_4._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnÖppnaFil_Click(object sender, EventArgs e)
        {
            //Visa "dialog" rutan där man anger ett filnamn / väljer fil.
            DialogResult resultat = dlgÖppnaFil.ShowDialog();
            if (resultat == DialogResult.OK)
            {
                //Rensar "items" som befinner sig i listboxen.
                this.lbxKontakt.Items.Clear();

                //Öppnar en ström.
                FileStream inStröm = new FileStream(dlgÖppnaFil.FileName, FileMode.Open, FileAccess.Read);

                //Skapar en läsare.
                StreamReader läsare = new StreamReader(inStröm);

                //Läs in kontakter en i taget.
                string förnamn = läsare.ReadLine();
                while (förnamn != null)
                {
                    Kontakt k = new Kontakt(förnamn, läsare.ReadLine(), läsare.ReadLine(), läsare.ReadLine());
                    this.lbxKontakt.Items.Add(k);

                    //Kolla om det finns nårgra nya kontakter.
                    förnamn = läsare.ReadLine();
                }                
                //Stänger filen.
                läsare.Dispose();
            }
        }

        private void btnSparaFil_Click(object sender, EventArgs e)
        {
            //Visa "dialog" rutan där man anger ett filnamn / väljer fil.
            DialogResult resultat = dlgSparaFil.ShowDialog();
            if (resultat == DialogResult.OK)
            {
                //Öppnar en ström.
                FileStream utStröm = new FileStream(this.dlgSparaFil.FileName, FileMode.OpenOrCreate, FileAccess.Write);

                //Skapar en skrivare.
                StreamWriter skrivare = new StreamWriter(utStröm);

                //Skriven en kontakt i taget.
                foreach (Kontakt k in this.lbxKontakt.Items)
                {
                    //srkiva en rad i taget (En för varje function).
                    skrivare.WriteLine(k.Förnamn);
                    skrivare.WriteLine(k.Efternamn);
                    skrivare.WriteLine(k.Epost);
                    skrivare.WriteLine(k.Telefonnummer);
                }
                //Stänger filen.
                skrivare.Dispose();
            }
        }


        private void btnLäggTill_Click(object sender, EventArgs e)
        {
            //Skapar en konto / kontakt.
            Kontakt kontakt = new Kontakt(this.tbxFörnamn.Text, this.tbxEfternamn.Text, this.tbxepost.Text, this.tbxTelefonnummer.Text);
            //Lägger till en item / kontakt i listan.
            this.lbxKontakt.Items.Add(kontakt);
        }

        private void btnTaBort_Click(object sender, EventArgs e)
        {
            //Ta bort den kontakten som är märkerad.
            lbxKontakt.Items.Remove(lbxKontakt.SelectedItem);
        }

        private void lbxKontakt_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.lbxKontakt.SelectedItem == null)
            {
                //Skriv ut den givna i de olika kontakts fälten.
                this.tbxFörnamn.Text = "";
                this.tbxEfternamn.Text = "";
                this.tbxepost.Text = "";
                this.tbxTelefonnummer.Text = "";
            }
            else
            {
                //Skapa ett objekt av de valda kontakterna.
                Kontakt selectedItem = this.lbxKontakt.SelectedItem as Kontakt;
                //Avger selected item functionen.
                this.tbxFörnamn.Text = selectedItem.Förnamn;
                this.tbxEfternamn.Text = selectedItem.Efternamn;
                this.tbxepost.Text = selectedItem.Epost;
                this.tbxTelefonnummer.Text = selectedItem.Telefonnummer;
            }
        }



        internal class Kontakt
        {
            private string efternamn;

            private string epost;

            private string telefonnr;


            public string Förnamn
            {
                get;
                set;
            }
            public string Efternamn
            {
                get;
                set;
            }

            public string Epost
            {
                get;
                set;
            }

            public string Telefonnummer
            {
                get;
                set;
            }

            public Kontakt(string förnamn, string efternamn, string epost, string telenr)
            {
                //Anger att de fyra values är lika med kontakterna.
                this.Förnamn = förnamn;
                this.Efternamn = efternamn;
                this.Epost = epost;
                this.Telefonnummer = telenr;
            }


            public override string ToString()
            {
                //Returnan efternamn i den givna fältet.
                return Förnamn + " " + Efternamn;
            }
        }
    }
}
