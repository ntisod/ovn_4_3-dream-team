﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Övning_4._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnÖppnaFil_Click(object sender, EventArgs e)
        {
            DialogResult resultat = dlgÖppnaFil.ShowDialog();
            if (resultat == DialogResult.OK)
            {
                this.lbxKontakt.Items.Clear();
                FileStream inStröm = new FileStream(dlgÖppnaFil.FileName, FileMode.Open, FileAccess.Read);
                StreamReader läsare = new StreamReader(inStröm);
                string förnamn = läsare.ReadLine();
                while (förnamn != null)
                {                    
                    Kontakt k = new Kontakt(förnamn, läsare.ReadLine(), läsare.ReadLine(), läsare.ReadLine());
                    this.lbxKontakt.Items.Add(k);
                    förnamn = läsare.ReadLine();
                }                
                läsare.Dispose();
            }
        }

        private void btnSparaFil_Click(object sender, EventArgs e)
        {
            DialogResult resultat = dlgSparaFil.ShowDialog();
            if (resultat == DialogResult.OK)
            {
                FileStream utStröm = new FileStream(this.dlgSparaFil.FileName, FileMode.OpenOrCreate, FileAccess.Write);
                StreamWriter skrivare = new StreamWriter(utStröm);
                foreach (Kontakt k in this.lbxKontakt.Items)
                {
                    skrivare.WriteLine(k.Förnamn);
                    skrivare.WriteLine(k.Efternamn);
                    skrivare.WriteLine(k.Epost);
                    skrivare.WriteLine(k.Telefonnummer);
                }
                skrivare.Dispose();
            }
        }


        private void btnLäggTill_Click(object sender, EventArgs e)
        {

            Kontakt kontakt = new Kontakt(this.tbxFörnamn.Text, this.tbxEfternamn.Text, this.tbxepost.Text, this.tbxTelefonnummer.Text);
            this.lbxKontakt.Items.Add(kontakt);
        }

        private void btnTaBort_Click(object sender, EventArgs e)
        {
            lbxKontakt.Items.Remove(lbxKontakt.SelectedItem);
        }

        private void lbxKontakt_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.lbxKontakt.SelectedItem == null)
            {
                this.tbxFörnamn.Text = "";
                this.tbxEfternamn.Text = "";
                this.tbxepost.Text = "";
                this.tbxTelefonnummer.Text = "";
            }
            else
            {
                Kontakt selectedItem = this.lbxKontakt.SelectedItem as Kontakt;
                this.tbxFörnamn.Text = selectedItem.Förnamn;
                this.tbxEfternamn.Text = selectedItem.Efternamn;
                this.tbxepost.Text = selectedItem.Epost;
                this.tbxTelefonnummer.Text = selectedItem.Telefonnummer;
            }
        }



        internal class Kontakt
        {
            private string efternamn;

            private string epost;

            private string telefonnr;


            public string Förnamn
            {
                get;
                set;
            }
            public string Efternamn
            {
                get;
                set;
            }

            public string Epost
            {
                get;
                set;
            }

            public string Telefonnummer
            {
                get;
                set;
            }

            public Kontakt(string förnamn, string efternamn, string epost, string telenr)
            {
                this.Förnamn = förnamn;
                this.Efternamn = efternamn;
                this.Epost = epost;
                this.Telefonnummer = telenr;
            }


            public override string ToString()
            {
                return Förnamn + " " + Efternamn;
            }
        }
    }
}
